# import os
# from dotenv import load_dotenv

# load_dotenv()

# # 기업마당 API 설정
# API_KEY = os.getenv("BIZINFO_API_KEY", "17986d31ec5f9cf3a864ffc5d8cf4420667bfffb4fc4decc025b895f9d2ab2d0")
# BASE_URL = "https://www.bizinfo.go.kr/uss/rss/bizinfoApi.do"

# # MySQL DB 설정 (백엔드와 동일하게)
# DB_CONFIG = {
#     "host": os.getenv("DB_HOST", "localhost"),
#     "port": int(os.getenv("DB_PORT", "3306")),
#     "user": os.getenv("DB_USER", "root"),
#     "password": os.getenv("DB_PASSWORD", "aivle"),
#     "database": os.getenv("DB_NAME", "randi2"),
#     "charset": "utf8mb4"
# }

# # Google Gemini API 키 (필요시)
# GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")

# MySQL 접속 정보
DB_CONFIG = {
    'host': '127.0.0.1',       # 나중에 AWS RDS 주소로 교체
    'user': 'root',            # MySQL 아이디
    'password': 'aivle', # 실제 비밀번호 입력
    'db': 'randi2',        # 스키마 이름
    'charset': 'utf8mb4'
}

# API 정보
API_KEY = "O5T1ww"
BASE_URL = "https://www.bizinfo.go.kr/uss/rss/bizinfoApi.do" 