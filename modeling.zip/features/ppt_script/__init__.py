"""
features.ppt_script 패키지
"""
from .script_llm import generate_script_and_qna
from .main_script import main
__all__ = ["generate_script_and_qna", "main"]
